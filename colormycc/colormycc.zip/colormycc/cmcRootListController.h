#import <Preferences/PSListController.h>

@interface cmcRootListController : PSListController

@end
