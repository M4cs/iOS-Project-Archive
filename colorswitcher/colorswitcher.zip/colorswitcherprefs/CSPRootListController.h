#import <Preferences/PSListController.h>

@interface CSPRootListController : PSListController

@end
