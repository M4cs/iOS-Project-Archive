#import <Preferences/PSListController.h>

@interface DarkSwitcherPrefs : PSListController

@end
