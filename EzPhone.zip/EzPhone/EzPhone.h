#import "ControlCenterUIKit/CCUIToggleModule.h"

@interface EzPhone : CCUIToggleModule
@property (nonatomic, assign, readwrite) BOOL EzPhone;
@end
