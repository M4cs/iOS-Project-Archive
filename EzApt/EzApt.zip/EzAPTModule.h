#import <ControlCenterUIKit/CCUIToggleModule.h>
#import <UIKit/UIKit.h>

@interface EzAPTModule : CCUIToggleModule
@property (nonatomic, assign, readwrite) BOOL EzAPT;
@end

