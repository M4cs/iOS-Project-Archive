#import "ControlCenterUIKit/CCUIToggleModule.h"

@interface EzSpotify : CCUIToggleModule
@property (nonatomic, assign, readwrite) BOOL EzSpotify;
@end
