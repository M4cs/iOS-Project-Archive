#import <Preferences/PSListController.h>

@interface RHPRootListController : PSListController

@end
