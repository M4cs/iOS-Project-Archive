#import <ControlCenterUIKit/CCUIToggleModule.h>
#import <UIKit/UIKit.h>

@interface EzRespringModule : CCUIToggleModule
@property (nonatomic, assign, readwrite) BOOL EzRespring;
@end

