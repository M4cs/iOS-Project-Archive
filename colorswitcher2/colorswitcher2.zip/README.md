# DarkSwitcher
___
Darken the background of your App Switcher.
___
## Known Bugs
___
- While moving cards it fades again.
___
### Pull Request
___
- Please add a pull request if you know any fixes possible!
