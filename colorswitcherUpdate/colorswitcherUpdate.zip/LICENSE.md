ADTP (Auxilium Development Team) License

Copyright © 2018 Auxilium Development Team

This license document may be copied and distributed openly, but making amends or changes is not permitted.

The Auxilium Development Team Products License is a free, copyright license for software and other works originating from the Auxilium Development Team.

Permission on behalf of the Auxilium Development Team is granted where due, free of charge, to any person obtaining a copy of this software and any associated code or documentation files (the "Software"), to handle the Software with limitations that protect the rights and efforts of the dedicated members of the mentioned personnel (the “Organization”). Any individual who has received the Software can use, mention, share, and discuss about such Software. However, limitations are brought to present with this license documentation, prohibiting certain actions relating to the Software and any associating assets such as written documentation, provided by the following conditions:

No individual shall redistribute amended copies of the Software, unless written permission is provided by the originating personnel. An individual is not granted access to the ability to use any part of the Software and referring it to his or her own, unless written permission by a member of the Organization or the Organization in its entirety is given. Previous offenders of the Auxilium Development Team Products License, caught performing actions such as but not limited to duplicating or amending without the written consent of the Organization shall be rejected the use and any chance of permission of using the entire or portions of the Software in or inside his or her works. It is expected that these rules will be followed professionally; bounding the discussed with integrity.

The above copyright documentation and this permission shall be present in all complete or partial instances of the Software.

If, under any circumstance, the Auxilium Development Team Products License is not followed, and the problematic personnel is discovered, repercussions may be applied where necessary and due.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRNGMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABLE, WHETHER IN AN ACTION OF CONTRACT OR AGREEMENT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OF OTHER DEALINGS IN THE SOFTWARE.

This license document was last revised on March 25, 2018 (3/25/18).