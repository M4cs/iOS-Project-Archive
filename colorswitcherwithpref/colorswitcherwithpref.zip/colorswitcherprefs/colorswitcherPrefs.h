#import <Preferences/PSListController.h>

@interface ColorSwitcherPrefs : PSListController

@end
