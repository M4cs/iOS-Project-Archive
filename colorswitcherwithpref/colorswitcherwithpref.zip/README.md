# DarkSwitcher
___
Darken the background of your App Switcher.
___
## Known Bugs
___
- ~~While moving cards it fades again.~~~ Fixed
___
## To Do
___
- Add libcolorpicker for paid
- Add UIColor prefs for free
- Add card stylization
___
### Pull Request
___
- Please add a pull request if you know any fixes possible!
